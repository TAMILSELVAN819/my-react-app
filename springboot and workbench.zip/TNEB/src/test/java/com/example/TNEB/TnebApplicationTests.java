package com.example.TNEB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TnebApplicationTests {

	@Test
	void contextLoads() {
	}

}
