package com.example.TNEB.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.TNEB.entity.CustomerTransaction;
@Repository
public interface TransactionRepository extends JpaRepository<CustomerTransaction, Long> {

}
