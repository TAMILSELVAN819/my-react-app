package com.example.TNEB.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
@Entity
@Data
public class CustomerTransaction {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String customerno;
    private String connectionType;
    private Double previousReading;
    private Double currentReading;
    private Double noOfUnits;
    private Double amount;
    private LocalDateTime readingDate;
    public CustomerTransaction() {}
}
