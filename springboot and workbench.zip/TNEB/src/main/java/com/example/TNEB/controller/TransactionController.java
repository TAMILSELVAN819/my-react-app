package com.example.TNEB.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.TNEB.Repository.TransactionRepository;
import com.example.TNEB.entity.CustomerTransaction;

@RestController
@RequestMapping("/api/transactions")
@CrossOrigin(origins = "http://localhost:5173")
public class TransactionController {

	@Autowired
    private TransactionRepository repository;
	
	@GetMapping
	public   List<CustomerTransaction> getAllTransactions()
	{
		return repository.findAll();
	}
	
	@PostMapping
	public  CustomerTransaction createTransaction(@RequestBody CustomerTransaction transaction)
	{
		if(transaction.getReadingDate()==null)
		{
			transaction.setReadingDate(LocalDateTime.now());
		}
		return repository.save(transaction);
	}
}
